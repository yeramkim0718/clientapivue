package racoi.Job;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import racoi.Dto.*;
import racoi.Repository.CompreBuzzRepository;
import racoi.Repository.InternetBuzzMappingRepository;
import racoi.Repository.InternetBuzzRepository;
import racoi.Repository.RelatedWordRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j // log 사용을 위한 lombok 어노테이션
@RequiredArgsConstructor // 생성자 DI를 위한 lombok 어노테이션
@Configuration
public class SimpleJobConfiguration {

    private final JobBuilderFactory jobBuilderFactory; // 생성자 DI 받음
    private final StepBuilderFactory stepBuilderFactory; // 생성자 DI 받음
    private final InternetBuzzRepository internetBuzzRepository;
    private final CompreBuzzRepository compreBuzzRepository;
    private final RelatedWordRepository relatedWordRepository;

    @Bean
    public Job cralweJob() {
        return jobBuilderFactory.get("crawling")
                .incrementer(new RunIdIncrementer())
                .start(crawle_compreBuzz())
                .build();
    }

    @Bean
    public Step crawle_internetBuzz() {
        return stepBuilderFactory.get("crawle_internetBuzz")
                .tasklet((contribution, chunkContext) -> {

                    System.out.println("internetbuzz");
                    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("headless");
                    options.addArguments("--disable-popup-blocking"); // 팝업 무시
                    options.addArguments("--disable-default-apps"); // 기본앱 사용안함
                    WebDriver driver = new ChromeDriver(options);
                    driver.get("https://www.racoi.or.kr/kobaco/nreport/ibuzz.do");

                    WebElement table = driver.findElement(By.id("content_body_list"));
                    List<WebElement> rows = table.findElements(By.tagName("tr"));

                    internetBuzzRepository.deleteAll();

                    for (int i = 0; i < rows.size(); i++) {

                        WebElement row = rows.get(i);
                        InternetBuzz buzz = new InternetBuzz();

                        String program = row.findElement(By.className("m01_tb01")).findElement(By.tagName("a")).getAttribute("title");

                        if (program.startsWith("* ")) {
                            program = program.replace("* ","");
                        }

                        if (program.startsWith(" * ")) {
                            program = program.replace(" * ","");
                        }

                        if (program.startsWith(" *")) {
                            program = program.replace(" *","");
                        }

                        if(program.endsWith("(종영)")) {
                            program = program.replace("(종영)","");
                        }

                        buzz.setProgram(program);
                        buzz.setChannel(row.findElement(By.className("m01_tb02")).getText());
                        buzz.setDays(row.findElement(By.className("m01_tb03")).getText());

                        buzz.setPost(row.findElement(By.className("m01_tb04")).getText().replace(",",""));
                        buzz.setComment(row.findElement(By.className("m01_tb05")).getText().replace(",",""));
                        buzz.setVideoView(row.findElement(By.className("m01_tb06")).getText().replace(",",""));
                        buzz.setNews(row.findElement(By.className("m01_tb07")).getText().replace(",",""));
                        buzz.setVideo(row.findElement(By.className("m01_tb08")).getText().replace(",",""));
                        buzz.setFamily(row.findElements(By.className("m01_tb09")).get(0).getText().replace(",",""));
                        buzz.setDetail(row.findElements(By.className("m01_tb09")).get(1).getText().replace(",",""));

                        InternetBuzzMapping mapping = new InternetBuzzMapping();
                        buzz.setInternetBuzzMapping(mapping);
                        mapping.setInternetBuzz(buzz);
                        internetBuzzRepository.save(buzz);

                    }
                    //System.out.println(new String(driver.getPageSource().getBytes(), StandardCharsets.UTF_8));
                    driver.quit();
                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    public Step crawle_compreBuzz() {
        return stepBuilderFactory.get("crawle_compreBuzz")
                .tasklet((contribution, chunkContext) -> {

                    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("headless");
                    options.addArguments("--disable-popup-blocking"); // 팝업 무시
                    options.addArguments("--disable-default-apps"); // 기본앱 사용안함
                    WebDriver driver = new ChromeDriver(options);
                    driver.get("https://www.racoi.or.kr/kobaco/nreport/totalresponse.do#");

                    WebElement table = driver.findElement(By.id("content_body_list"));
                    List<WebElement> rows = table.findElements(By.tagName("tr"));

                    compreBuzzRepository.deleteAll();

                    for (int i = 0; i < rows.size(); i++) {

                        WebElement row = rows.get(i);
                        CompreBuzz buzz = new CompreBuzz();

                        String program = row.findElement(By.className("m03_tb01")).findElement(By.tagName("a")).getAttribute("title");

                        if (program.startsWith("* ")) {
                            program = program.replace("* ","");
                        }

                        if (program.startsWith(" * ")) {
                            program = program.replace(" * ","");
                        }

                        if (program.startsWith(" *")) {
                            program = program.replace(" *","");
                        }

                        if(program.endsWith("(종영)")) {
                            program = program.replace("(종영)","");
                        }

                        buzz.setProgram(program);
                        buzz.setStartDate(row.findElement(By.className("m03_tb02")).getText());
                        buzz.setChannel(row.findElement(By.className("m03_tb03")).getText());
                        buzz.setDays(row.findElement(By.className("m03_tb04")).getText());

                        buzz.setPost(row.findElement(By.className("m03_tb07")).getText().replace(",",""));
                        buzz.setComment(row.findElement(By.className("m03_tb08")).getText().replace(",",""));
                        buzz.setVideoView(row.findElement(By.className("m03_tb09")).getText().replace(",",""));

                        buzz.setNews(row.findElement(By.className("m03_tb05")).getText().replace(",",""));
                        buzz.setVideo(row.findElement(By.className("m03_tb06")).getText().replace(",",""));

                        buzz.setFamily(row.findElement(By.className("m03_tb10")).getText().replace(",",""));
                        buzz.setIndividual(row.findElement(By.className("m03_tb11")).getText().replace(",",""));
                        buzz.setMan(row.findElement(By.className("m03_tb12")).getText().replace(",",""));
                        buzz.setWoman(row.findElement(By.className("m03_tb13")).getText().replace(",",""));
                        buzz.setTeenager(row.findElement(By.className("m03_tb14")).getText().replace(",",""));
                        buzz.setTwenties(row.findElement(By.className("m03_tb15")).getText().replace(",",""));
                        buzz.setThirties(row.findElement(By.className("m03_tb16")).getText().replace(",",""));
                        buzz.setFourties(row.findElement(By.className("m03_tb17")).getText().replace(",",""));
                        buzz.setFifties(row.findElements(By.className("m03_tb18")).get(0).getText().replace(",",""));
                        buzz.setSixties(row.findElements(By.className("m03_tb18")).get(1).getText().replace(",",""));
                        buzz.setTvVod(row.findElement(By.className("m03_tb19")).getText().replace(",",""));

                        buzz.setPcLive(row.findElement(By.className("m03_tb20")).getText().replace(",",""));
                        buzz.setPcVod(row.findElement(By.className("m03_tb21")).getText().replace(",",""));

                        buzz.setMobileLive(row.findElement(By.className("m03_tb22")).getText().replace(",",""));
                        buzz.setMobileVod(row.findElement(By.className("m03_tb23")).getText().replace(",",""));

                        CompreBuzzMapping mapping = new CompreBuzzMapping();
                        mapping.setCompreBuzz(buzz);
                        buzz.setCompreBuzzMapping(mapping);
                        compreBuzzRepository.save(buzz);

                    }
                    //System.out.println(new String(driver.getPageSource().getBytes(), StandardCharsets.UTF_8));
                    driver.quit();

                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    public Step crawle_relatedWords() {

        return stepBuilderFactory.get("crawle_relatedWords")
                .tasklet((contribution, chunkContext) -> {

                    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");

                    ChromeOptions options = new ChromeOptions();
                    WebDriver driver = new ChromeDriver(options);
                    WebDriverWait wait = new WebDriverWait(driver,10);

                    driver.get("https://www.racoi.or.kr/kobaco/nreport/weekmorp.do");
                    driver.manage().window().maximize();

                    WebElement table = driver.findElement(By.id("morplist"));
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("morplist")));
                    List<WebElement> rows = table.findElements(By.tagName("tr"));

                    WebElement adjective = driver.findElement(By.id("graph_btn_Adjective"));
                    while (!adjective.getAttribute("class").equals("on")) {
                        adjective.click();
                    }

                    String pre_value = "-1";

                    for (int i = 0; i < rows.size(); i++) {

                        String channel = "";
                        String days = "";

                        WebElement row = rows.get(i);
                        String program = row.findElement(By.className("m02b_tb01")).getText();

                        if (program.startsWith("* ")) {
                            program = program.replace("* ","");
                        }

                        if (program.startsWith(" * ")) {
                            program = program.replace(" * ","");
                        }

                        if (program.startsWith(" *")) {
                            program = program.replace(" *","");
                        }

                        if(program.endsWith("(종영)")) {
                            program = program.replace("(종영)","");
                        }

                        channel = row.findElement(By.className("m02b_tb02")).getText();
                        days = row.findElement(By.className("m02b_tb03")).getText();

                        String item_value = "initial";
                        List<WebElement> items = null;

                        do {
                            row.findElement(By.className("m02b_tb01")).click();
                            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
                            WebElement graph = driver.findElement(By.id("graph_01"));
                            items = graph.findElements(By.xpath("//*[starts-with(@role,'menuitem')]"));
                            items.get(0).click();
                            item_value = items.get(0).findElement(By.tagName("desc")).getText();

                        } while(item_value.equals(pre_value));

                        for (int j=0;j<10;j++) {
                            String[] words = items.get(j).findElement(By.tagName("desc")).getText().split(" ");
                            String amount = words[0];
                            String word = words[1];

                            RelatedWord relatedWord = new RelatedWord();
                            relatedWord.setProgram(program);
                            relatedWord.setChannel(channel);
                            relatedWord.setDays(days);
                            relatedWord.setPriority(String.valueOf(j+1));
                            relatedWord.setWord(word);
                            relatedWord.setAmount(amount);
                            relatedWordRepository.save(relatedWord);

                            System.out.println(relatedWord.toString());

                            if(j!=9) {
                                items.get(j+1).click();
                            }

                        }

                        pre_value = item_value;
                    }
                    //System.out.println(new String(driver.getPageSource().getBytes(), StandardCharsets.UTF_8));
                    driver.quit();

                    return RepeatStatus.FINISHED;
                })
                .build();
    }
}