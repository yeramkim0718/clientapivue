package racoi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import racoi.Dto.RelatedWord;
import racoi.Dto.RelatedWordIdentifier;

public interface RelatedWordRepository extends JpaRepository<RelatedWord, RelatedWordIdentifier> {
}
