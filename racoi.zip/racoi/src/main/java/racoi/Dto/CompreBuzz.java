package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Table(name ="compre_buzz")
@Entity
@IdClass(CompreBuzzIdentifier.class)
public class CompreBuzz {

    @Id @Column(length = 100) private String program;
    @Id @Column(length = 100) private String startDate;
    @Id @Column(length = 100) private String channel;
    @Id @Column(length = 100) private String days;
    private String post;
    private String comment;
    private String videoView;
    private String news;
    private String video;
    private String family;
    private String individual;
    private String man;
    private String woman;
    private String teenager;
    private String twenties;
    private String thirties;
    private String fourties;
    private String fifties;
    private String sixties;
    private String tvVod;
    private String pcLive;
    private String pcVod;
    private String mobileLive;
    private String mobileVod;

    @OneToOne(mappedBy = "compreBuzz", cascade = CascadeType.ALL)
    private CompreBuzzMapping compreBuzzMapping;

    @Override
    public String toString() {
        return "CompreBuzz{" +
                "program='" + program + '\'' +
                ", startDate='" + startDate + '\'' +
                ", channel='" + channel + '\'' +
                ", days='" + days + '\'' +
                ", post='" + post + '\'' +
                ", comment='" + comment + '\'' +
                ", videoView='" + videoView + '\'' +
                ", news='" + news + '\'' +
                ", video='" + video + '\'' +
                ", family='" + family + '\'' +
                ", individual='" + individual + '\'' +
                ", man='" + man + '\'' +
                ", woman='" + woman + '\'' +
                ", teenager='" + teenager + '\'' +
                ", twenties='" + twenties + '\'' +
                ", thirties='" + thirties + '\'' +
                ", fourties='" + fourties + '\'' +
                ", fifties='" + fifties + '\'' +
                ", sixties='" + sixties + '\'' +
                ", tvVod='" + tvVod + '\'' +
                ", pcLive='" + pcLive + '\'' +
                ", pcVod='" + pcVod + '\'' +
                ", mobileLive='" + mobileLive + '\'' +
                ", mobileVod='" + mobileVod + '\'' +
                '}';
    }
}
