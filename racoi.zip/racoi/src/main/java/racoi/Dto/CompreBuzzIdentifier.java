package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter @Setter
public class CompreBuzzIdentifier implements Serializable {

    private String program;
    private String startDate;
    private String channel;
    private String days;

    @Override
    public int hashCode() {
        String identifier  = program.concat(startDate).concat(channel).concat(days);
        return identifier.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this== o)
            return true;
        if (o == null || getClass() != o.getClass() )
            return false;

        CompreBuzzIdentifier compreBuzzIdentifier = (CompreBuzzIdentifier)  o;
        return Objects.equals(program, compreBuzzIdentifier.getProgram()) &&
                Objects.equals(startDate, compreBuzzIdentifier.getStartDate()) &&
                Objects.equals(channel, compreBuzzIdentifier.getChannel()) &&
                Objects.equals(days, compreBuzzIdentifier.getDays());

    }
}
