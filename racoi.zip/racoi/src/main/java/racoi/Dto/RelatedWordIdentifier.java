package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
public class RelatedWordIdentifier implements Serializable {
    private String program;
    private String channel;
    private String days;
    private String priority;

    @Override
    public int hashCode() {
        String identifier  = program.concat(channel).concat(days).concat(priority);
        return identifier.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this== o)
            return true;
        if (o == null || getClass() != o.getClass() )
            return false;

        RelatedWordIdentifier relatedWordIdentifier = (RelatedWordIdentifier)  o;
        return Objects.equals(program, relatedWordIdentifier.getProgram()) &&
                Objects.equals(channel, relatedWordIdentifier.getChannel()) &&
                Objects.equals(days, relatedWordIdentifier.getDays()) &&
                Objects.equals(priority,relatedWordIdentifier.getPriority()) ;

    }
}
