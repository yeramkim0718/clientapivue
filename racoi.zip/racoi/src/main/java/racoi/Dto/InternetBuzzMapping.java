package racoi.Dto;

import lombok.Data;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table
@Getter
@Setter
public class InternetBuzzMapping {

    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String contentId;
    private String contentsetId;

    @OneToOne
    @JoinColumns ({@JoinColumn (name = "program",referencedColumnName="program"),
            @JoinColumn (name = "channel",referencedColumnName="channel"),
            @JoinColumn (name = "days",referencedColumnName="days")})
    private InternetBuzz internetBuzz;

}