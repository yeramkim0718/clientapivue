package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter @Setter
public class InternetBuzzIdentifier implements Serializable {
    private String program;
    private String channel;
    private String days;

    @Override
    public int hashCode() {
        String identifier  = program.concat(channel).concat(days);
        return identifier.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this== o)
            return true;
        if (o == null || getClass() != o.getClass() )
            return false;

        InternetBuzzIdentifier internetBuzzIdentifier = (InternetBuzzIdentifier)  o;
        return Objects.equals(program, internetBuzzIdentifier.getProgram()) &&
                Objects.equals(channel, internetBuzzIdentifier.getChannel()) &&
                Objects.equals(days, internetBuzzIdentifier.getDays());

    }
}
