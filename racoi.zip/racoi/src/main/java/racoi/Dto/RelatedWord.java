package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Table(name ="related_word")
@Entity
@IdClass(RelatedWordIdentifier.class)

public class RelatedWord {
    @Id @Column(length = 100) private String program;
    @Id @Column(length = 100) private String channel;
    @Id @Column(length = 100) private String days;
    @Id @Column(length = 100) private String priority;
    private String word;
    private String amount;
    private String contentId;
    private String contentsetId;

    @Override
    public String toString() {
        return "RelatedWord{" +
                "program='" + program + '\'' +
                ", channel='" + channel + '\'' +
                ", days='" + days + '\'' +
                ", priority='" + priority + '\'' +
                ", word='" + word + '\'' +
                ", amount='" + amount + '\'' +
                ", contentId='" + contentId + '\'' +
                ", contentsetId='" + contentsetId + '\'' +
                '}';
    }
}
