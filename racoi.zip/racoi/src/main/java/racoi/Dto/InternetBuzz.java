package racoi.Dto;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Table(name ="internet_buzz")
@Entity
@IdClass(InternetBuzzIdentifier.class)
public class InternetBuzz {

    @Id private String program;
    @Id private String channel;
    @Id private String days;

    private String post;
    private String comment;
    private String videoView;
    private String news;
    private String video;
    private String family;
    private String detail;

    @OneToOne(mappedBy = "internetBuzz", cascade = CascadeType.ALL)
    private InternetBuzzMapping internetBuzzMapping;

    @Override
    public String toString() {
        return "InternetBuzz{" +
                "program='" + program + '\'' +
                ", channel='" + channel + '\'' +
                ", days='" + days + '\'' +
                ", post='" + post + '\'' +
                ", comment='" + comment + '\'' +
                ", videoView='" + videoView + '\'' +
                ", news='" + news + '\'' +
                ", video='" + video + '\'' +
                ", family='" + family + '\'' +
                ", detail='" + detail + '}';
    }
}



